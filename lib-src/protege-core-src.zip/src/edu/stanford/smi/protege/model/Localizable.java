package edu.stanford.smi.protege.model;

/**
 * TODO Class Comment
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public interface Localizable {
    void localize(KnowledgeBase kb);
}
