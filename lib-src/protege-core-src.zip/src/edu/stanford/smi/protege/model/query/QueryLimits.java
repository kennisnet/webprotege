package edu.stanford.smi.protege.model.query;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public interface QueryLimits {

}
