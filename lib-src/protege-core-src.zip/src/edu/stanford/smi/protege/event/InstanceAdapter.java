package edu.stanford.smi.protege.event;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class InstanceAdapter implements InstanceListener {

    public void directTypeAdded(InstanceEvent event) {
    }

    public void directTypeRemoved(InstanceEvent event) {
    }

}
