package edu.stanford.smi.protege.event;

public class ServerProjectAdapter implements ServerProjectListener {
    
    public void projectNotificationReceived(ServerProjectNotificationEvent event) {
    }

    public void projectStatusChanged(ServerProjectStatusChangeEvent event) {
    }
    
    public void beforeProjectSessionClosed(ServerProjectSessionClosedEvent event) {
    }
}
