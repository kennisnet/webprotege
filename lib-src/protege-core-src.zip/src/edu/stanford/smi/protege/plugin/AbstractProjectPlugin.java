package edu.stanford.smi.protege.plugin;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public abstract class AbstractProjectPlugin extends AbstractPlugin implements ProjectPlugin {
}
