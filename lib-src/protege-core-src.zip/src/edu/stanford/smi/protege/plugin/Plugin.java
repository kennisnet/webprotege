package edu.stanford.smi.protege.plugin;

import edu.stanford.smi.protege.util.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public interface Plugin extends Disposable {
    String getName();
}
