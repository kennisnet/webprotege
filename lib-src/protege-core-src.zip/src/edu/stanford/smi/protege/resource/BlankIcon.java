package edu.stanford.smi.protege.resource;

import java.awt.*;

import javax.swing.*;

/**
 * TODO Class Comment
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */

class BlankIcon implements Icon {
    public void paintIcon(Component c, Graphics g, int x, int y) {
        // do nothing
    }
    public int getIconWidth() {
        return 18;
    }
    public int getIconHeight() {
        return 18;
    }
}
