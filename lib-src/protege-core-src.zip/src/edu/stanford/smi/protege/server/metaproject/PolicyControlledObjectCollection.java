package edu.stanford.smi.protege.server.metaproject;


public interface PolicyControlledObjectCollection {

    String getName();

    void setName(String name);

}
