package edu.stanford.smi.protege.server.framestore.background;

public interface ServerCachedState {

}
