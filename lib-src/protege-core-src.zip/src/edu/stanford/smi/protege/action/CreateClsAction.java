/*
 * Created on Jul 15, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.stanford.smi.protege.action;

import edu.stanford.smi.protege.resource.*;
import edu.stanford.smi.protege.util.*;

/**
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 *
 * TODO Class Comment
 */
public abstract class CreateClsAction extends CreateAction {

    private static final long serialVersionUID = 3430794066285629201L;

    protected CreateClsAction() {
        super(ResourceKey.CLASS_CREATE);
    }
}
