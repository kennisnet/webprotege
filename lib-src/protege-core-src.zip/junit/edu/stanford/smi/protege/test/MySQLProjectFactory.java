package edu.stanford.smi.protege.test;

import edu.stanford.smi.protege.model.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class MySQLProjectFactory extends AbstractProjectFactory {
    public Project createProject() {
        return null;
    }
}
