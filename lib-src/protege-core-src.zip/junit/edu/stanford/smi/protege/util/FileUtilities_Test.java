package edu.stanford.smi.protege.util;

import edu.stanford.smi.protege.test.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class FileUtilities_Test extends APITestCase {
    public void testNothing() {
    }

}
