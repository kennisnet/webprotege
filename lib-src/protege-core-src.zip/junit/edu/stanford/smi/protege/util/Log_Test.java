package edu.stanford.smi.protege.util;

import edu.stanford.smi.protege.test.*;

/**
 * Unit test for the Log class
 *
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class Log_Test extends APITestCase {

    public void testNull() {
        
    }
}
