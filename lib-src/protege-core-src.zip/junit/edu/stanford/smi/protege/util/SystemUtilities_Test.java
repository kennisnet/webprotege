package edu.stanford.smi.protege.util;

import junit.framework.*;

/**
 * Unit tests for the SystemUtilities class
 */

public class SystemUtilities_Test extends TestCase {
    public void testNull() {
    }
}
