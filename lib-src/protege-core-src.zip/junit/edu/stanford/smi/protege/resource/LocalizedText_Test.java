package edu.stanford.smi.protege.resource;

import junit.framework.*;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class LocalizedText_Test extends TestCase {
    public void testSimple() {
    }
}
