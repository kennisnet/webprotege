package edu.stanford.smi.protege.storage.clips;

import junit.framework.*;

/**
 * Test suite for unit tests of classes in this package.
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class AllTests {

    public static TestSuite suite() {
        TestSuite suite = new TestSuite("storage.clips");
        return suite;
    }
}
